# TelhasTizi v7 — Verplichte leerlingnaam + gedeeld Leerlingenbord

## Belangrijk: voor het gedeelde leerlingenbord is een gratis Supabase-database nodig

1. Maak een Supabase project via https://supabase.com/ (controleer de actuele gratis limieten).
2. Ga naar SQL Editor en voer **supabase-setup.sql** uit.
3. Open je Netlify site bij **Project configuration > Environment variables**. Voeg toe:
   - `SUPABASE_URL` = de Project URL van Supabase (bijvoorbeeld `https://abcdefgh.supabase.co`)
   - `SUPABASE_SERVICE_ROLE_KEY` = de geheime server-side service_role key uit Supabase Project Settings / API Keys. **Gebruik NIET de publishable / anon key.**
4. Deploy het complete project inclusief `netlify/functions/leerlingen.mjs`, via GitHub gekoppeld aan Netlify of Netlify CLI. Een normale statische HTML drop uploadt serverfuncties niet altijd.
5. Start een nieuwe Netlify deploy. Open de website in twee verschillende browsers: eerst moet iedere leerling een naam invullen, daarna zie je alle leerlingen via het tabblad **Leerlingenbord**.

**LET OP:** Zonder Supabase blijft het naamregistratiescherm geblokkeerd met een duidelijke melding. Dit is bewust zo: we doen niet alsof het gedeelde leaderboard werkt wanneer er geen gedeelde database is.

**Privacy:** Het bord maakt weergavenamen, aantal gecontroleerde vragen, aantal goede antwoorden, oefensessies en onderwerpen openbaar voor bezoekers van het bord. Gebruik bij voorkeur bijnamen in plaats van volledige echte namen. Antwoordteksten worden niet online gezet door de leerlingenfunctie. De geheime studenttoken staat alleen in de browseropslag en wordt niet op het bord getoond.

**Beperkingen:** dit zijn zelfgerapporteerde oefenstatistieken, geen verifieerbare cijfers of beveiligde schoolaccounts. Dit basisprototype heeft nog geen docentenpaneel, wachtwoorden, moderatie of duurzame antimisbruiklimieten. Wie gegevens verwijdert of van apparaat wisselt kan zonder account zijn identiteit niet herstellen. Een onbeveiligde openbare registratie kan door bots misbruikt worden; voeg voor een openbare klasomgeving authenticatie, schooltoestemming en limieten toe.

**Bestaande progressie:** na aanmelding synchroniseert het programma bestaande lokaal opgeslagen oefenresultaten naar het profiel. De statistieken worden per browser bewaard en daarnaast gedeeld op het bord. De bestaande Gemini AI Netlify-functie blijft apart geconfigureerd via `GEMINI_API_KEY`.

---

## v5.1 — Startup crash fixed

This release restores the missing UI render, practice/session/navigation and theory functions that were accidentally omitted from v5. Verified dashboard, theory, chapters and practice question navigation in a JavaScript runtime.

## v5 boekgebaseerde theorie

- Theoriepagina's opnieuw opgebouwd op basis van de door de gebruiker aangeleverde boekfoto's van **Hoofdstuk 2: Kracht en beweging**.
- Ondersteunde paragrafen: **2.1 Soorten krachten**, **2.2 Krachten meten**, **2.3 Resulterende kracht**, **2.4 Kracht en versnelling** en **2.5 Veiligheid in het verkeer**.
- Oefenvragen sluiten nu inhoudelijk aan op deze paragrafen.
- Lokale voortgangssleutel vernieuwd naar `telhastizi-v5-book` zodat oude, niet-passende demo-data niet in de weg zit.

## v4 speed improvements

- Removed third-party Google Fonts requests that could delay the initial website display. Uses fast system fonts instead.
- The dashboard renders immediately, without waiting for the Gemini status endpoint.
- AI status check has a 3.5-second timeout and updates only its status badge.
- These changes speed up the browser-side load. If the Netlify URL itself is slow to respond, that depends on hosting/network conditions.

# TelhasTizi — Gemini Free AI edition

TelhasTizi is een oefenwebsite voor Nederlandse natuurkunde (3 VWO). De demo-oefeningen, theorie, symboolwoordenboek, formules en lokale voortgang werken zonder API-sleutel. Deze versie gebruikt **Google Gemini** voor echte AI-chat en het genereren van nieuwe vragen.

## Eenmalig: gratis Gemini API-sleutel
1. Ga naar https://aistudio.google.com/apikey en maak een API-sleutel voor een project met toegang tot de Gemini API. Gebruik de gratis tier voor zover deze voor jouw account en land beschikbaar is.
2. **Deel de sleutel niet**. Plaats die nooit in `index.html` of `app.js`.
3. Ga in Netlify naar jouw project → **Project configuration → Environment variables → Add a variable**. Naam: `GEMINI_API_KEY`; waarde: jouw sleutel. Stel deze zo mogelijk in voor de Functions scope. Optioneel: `GEMINI_MODEL` = `gemini-2.5-flash` (standaard; kies eventueel een ander model dat onder jouw gratis quota valt).
4. Start een nieuwe Netlify deploy nadat je de variabele hebt opgeslagen.

## Website mét AI publiceren (BELANGRIJK)
Een gewone statische upload naar Netlify Drop is niet gegarandeerd voldoende om een serverless AI-functie te deployen. Gebruik bij voorkeur **Git** of **Netlify CLI**:

### Optie A: GitHub (aanbevolen)
1. Pak de zip uit. Maak op https://github.com/new een nieuwe repository en upload **de inhoud van de `telhastizi` map** naar de repository-root (`index.html`, `app.js`, `netlify.toml`, `netlify/functions/ai.mjs` etc.).
2. Ga naar https://app.netlify.com/start → **Import from Git** → selecteer repository.
3. Base directory leeg, build command leeg, publish directory `.`. Netlify leest `netlify.toml` en pakt `netlify/functions` mee.
4. Voeg `GEMINI_API_KEY` toe in Netlify zoals hierboven, deploy opnieuw.

### Optie B: Netlify CLI
1. Installeer Node.js (indien nodig), gebruik `npx netlify-cli login`.
2. Open een terminal **in de uitgepakte `telhastizi` map** en voer `npx netlify-cli deploy --prod` uit. Volg de stappen om jouw bestaande site te kiezen. Een CLI-deploy kan serverless functies uploaden.
3. Configureer de API-sleutel in Netlify en deploy opnieuw.

## Test
- Op je live site verschijnt bovenaan **AI verbonden** zodra de serverfunctie een Gemini-sleutel ziet.
- Klik **Oefenvragen → Genereer met AI**, of ga naar **AI Tutor** en stel een vraag.
- Werkt het niet? Ga naar `https://JOUW-SITE.netlify.app/.netlify/functions/ai`. De JSON zou `{"available":true,"provider":"Gemini"}` moeten tonen. Bij `false` mist de sleutel of is de deploy niet opnieuw uitgevoerd; bij 404 is de functie niet gedeployed.
- Test ook of de daadwerkelijk gestelde AI-vraag werkt, want `available: true` betekent alleen dat de sleutel is ingesteld, niet dat Gemini de sleutel accepteert.

## Let op
- Gratis is **niet onbeperkt**: quota, modeltoegang en limieten kunnen veranderen. Kies géén betaald plan als je gratis wilt blijven. Houd Google AI Studio quota in de gaten.
- De functies bevatten een eenvoudige *best effort* per-IP begrenzing van 12 verzoeken per minuut per warme functie-instantie. Die is **niet voldoende voor een publieke site**: iedereen kan jouw quota opmaken. Deel de link alleen met vertrouwde personen; voor publiek gebruik zijn authenticatie en duurzame server-side rate limiting nodig.
- De AI genereert wiskundige antwoorden, maar die zijn **niet onafhankelijk numeriek geverifieerd**; verifieer nieuwe vraagantwoorden voordat je ze als toetsmateriaal gebruikt.
- De API-sleutel blijft aan de serverkant. Chatberichten en onderwerpcontext gaan naar Google's Gemini-dienst. Verstuur geen privacygevoelige informatie.
- Geen officiële Polaris-hoofdstukken: alle onderwerpen zijn demo-indelingen.
- Voortgang wordt lokaal in de browser opgeslagen, niet gesynchroniseerd met een account.
- De website is geschreven in HTML/CSS/JavaScript en vereist geen framework-build.

## Update: antwoordcontrole gerepareerd (v3)
De antwoordcontrole accepteert Nederlandse komma's en Engelse punten, wetenschappelijke notatie, optionele SI-eenheden en enkele equivalente eenheden (zoals 36 km/h = 10 m/s, 3,5 kJ = 3500 J). Meerkeuze-antwoorden worden nu op dezelfde manier beoordeeld. Numerieke toleranties houden rekening met afronding (0,5%, minimaal 0,01 in de doel-eenheid).

**Let op:** Antwoorden die eerder fout beoordeeld zijn, worden niet automatisch opnieuw beoordeeld in je bestaande browsergeschiedenis. Controleer die vragen opnieuw via de oefenmodus. Niet elke mogelijke natuurkundige eenheid of algebraïsche uitdrukking wordt ondersteund.

## v6 — uitgebreide lessen
De vijf paragrafen bevatten nu diepgaande uitleg, originele schematische tekeningen, formuleuitleg, rekenvoorbeelden en kennischecks met openklapbare antwoorden. Gebaseerd op door de gebruiker gefotografeerde hoofdstukpagina's; niet woordelijk overgenomen. De bestaande oefenvragen, AI-koppeling en symboolwoordenlijst blijven aanwezig.
