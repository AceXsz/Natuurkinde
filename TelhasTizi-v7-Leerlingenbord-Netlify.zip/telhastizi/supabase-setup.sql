-- Run this in the Supabase SQL editor. Never expose the service role key in the browser.
create table if not exists public.telhastizi_students (
  id uuid primary key,
  display_name text not null check (char_length(display_name) between 2 and 32),
  token_hash text not null,
  answered integer not null default 0 check (answered >= 0),
  correct integer not null default 0 check (correct >= 0 and correct <= answered),
  sessions integer not null default 0 check (sessions >= 0),
  topics jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.telhastizi_students enable row level security;
-- No public policies: the Netlify function uses the server-side service-role key.
revoke all on public.telhastizi_students from anon, authenticated;
create index if not exists telhastizi_students_rank_idx on public.telhastizi_students(answered desc);
