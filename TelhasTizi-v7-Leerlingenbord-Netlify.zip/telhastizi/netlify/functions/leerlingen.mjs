import { randomBytes, randomUUID, createHash, timingSafeEqual } from 'node:crypto';

const headers = { 'content-type':'application/json; charset=utf-8', 'cache-control':'no-store', 'access-control-allow-origin':'*', 'access-control-allow-headers':'content-type', 'access-control-allow-methods':'GET,POST,OPTIONS' };
const response=(status,body)=>({statusCode:status,headers,body:JSON.stringify(body)});
const url=(process.env.SUPABASE_URL||'').replace(/\/$/,'');
const secret=process.env.SUPABASE_SERVICE_ROLE_KEY||'';
const enabled=()=>/^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(url)&&!!secret;
const hash=s=>createHash('sha256').update(String(s)).digest('hex');
async function db(path,method='GET',body){
 const r=await fetch(url+'/rest/v1/'+path,{method,headers:{apikey:secret,Authorization:`Bearer ${secret}`, 'content-type':'application/json',Prefer:'return=representation'},body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(7000)});
 const data=await r.json().catch(()=>null);
 if(!r.ok)throw new Error('Database fout ('+r.status+'): '+String(data?.message||'controleer tabel en instellingen'));
 return data;
}
const allowedTopics=['soorten','meten','resulterende','versnelling','veiligheid'];
function cleanTotals(body){
 const topics={};for(const key of allowedTopics){let t=body?.topics?.[key]||{};topics[key]={answered:Math.min(100000,Math.max(0,Math.floor(Number(t.answered)||0))),correct:Math.min(100000,Math.max(0,Math.floor(Number(t.correct)||0)))};topics[key].correct=Math.min(topics[key].correct,topics[key].answered)}
 const answered=Math.min(100000,Math.max(0,Math.floor(Number(body.answered)||0))), correct=Math.min(answered,Math.max(0,Math.floor(Number(body.correct)||0))),sessions=Math.min(100000,Math.max(0,Math.floor(Number(body.sessions)||0)));
 return {answered,correct,sessions,topics};
}
export async function handler(event){
 if(event.httpMethod==='OPTIONS')return {statusCode:204,headers,body:''};
 if(!enabled())return response(503,{error:'Het gedeelde leerlingenbord moet nog gekoppeld worden aan Supabase.',setup_required:true});
 try{
  if(event.httpMethod==='GET'){
   const rows=await db('telhastizi_students?select=id,display_name,answered,correct,sessions,topics,updated_at&order=answered.desc&limit=100');
   return response(200,{students:rows});
  }
  if(event.httpMethod!=='POST')return response(405,{error:'Methode niet toegestaan'});
  if((event.body||'').length>14000)return response(413,{error:'Verzoek te groot'});
  const input=JSON.parse(event.body||'{}');
  if(input.action==='register'){
   const display_name=String(input.name||'').trim().replace(/\s+/g,' ');
   if(display_name.length<2||display_name.length>32||/[<>\n\r]/.test(display_name))return response(400,{error:'Gebruik een naam tussen 2 en 32 tekens.'});
   const id=randomUUID(),token=randomBytes(32).toString('hex');
   await db('telhastizi_students','POST',{id,display_name,token_hash:hash(token),answered:0,correct:0,sessions:0,topics:{}});
   return response(201,{id,token,display_name});
  }
  if(input.action==='progress'){
   const id=String(input.id||''),token=String(input.token||'');
   if(!/^[a-f0-9-]{36}$/.test(id)||!(/^[a-f0-9]{64}$/.test(token)))return response(401,{error:'Ongeldige leerlinggegevens'});
   const rows=await db('telhastizi_students?select=token_hash,answered,correct,sessions,topics&id=eq.'+encodeURIComponent(id)+'&limit=1');
   if(!rows?.length)return response(404,{error:'Leerling niet gevonden'});
   const a=Buffer.from(rows[0].token_hash,'hex'),b=Buffer.from(hash(token),'hex');
   if(a.length!==b.length||!timingSafeEqual(a,b))return response(401,{error:'Leerlingtoken onjuist'});
   const totals=cleanTotals(input);
   // Stats are non-decreasing. These are study indicators, not verified grades.
   const prev=rows[0], topics={};
   for(const key of allowedTopics){let old=prev.topics?.[key]||{},n=totals.topics[key];topics[key]={answered:Math.max(n.answered,old.answered||0),correct:Math.max(n.correct,old.correct||0)};topics[key].correct=Math.min(topics[key].correct,topics[key].answered)}
   await db('telhastizi_students?id=eq.'+encodeURIComponent(id),'PATCH',{answered:Math.max(prev.answered,totals.answered),correct:Math.min(Math.max(prev.correct,totals.correct),Math.max(prev.answered,totals.answered)),sessions:Math.max(prev.sessions,totals.sessions),topics,updated_at:new Date().toISOString()});
   return response(200,{ok:true});
  }
  return response(400,{error:'Onbekende actie'});
 }catch(e){return response(500,{error:process.env.NETLIFY_DEV?'Databasefout: '+e.message:'Leerlingenbord tijdelijk niet beschikbaar. Controleer Supabase-instellingen.'})}
}
