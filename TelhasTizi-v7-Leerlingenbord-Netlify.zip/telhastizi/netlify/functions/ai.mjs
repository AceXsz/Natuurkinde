// TelhasTizi Gemini server function. Keep GEMINI_API_KEY in Netlify environment variables.
const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'}});
const buckets=new Map();
function limited(ip){const now=Date.now();if(buckets.size>2000)for(const [k,v] of buckets)if(now-v.start>60000)buckets.delete(k);let b=buckets.get(ip);if(!b||now-b.start>60000){b={start:now,n:0};buckets.set(ip,b)}return ++b.n>12}
const clean=(v,max=200)=>String(v??'').slice(0,max);
export default async function(request){
  if(request.method==='GET')return json({available:Boolean(process.env.GEMINI_API_KEY),provider:'Gemini'});
  if(request.method!=='POST')return json({error:'Methode niet toegestaan'},405);
  if(!process.env.GEMINI_API_KEY)return json({error:'Stel GEMINI_API_KEY in bij Netlify Environment variables.'},503);
  if(limited(request.headers.get('x-nf-client-connection-ip')||request.headers.get('x-forwarded-for')||'unknown'))return json({error:'Te veel verzoeken. Probeer het over een minuut opnieuw.'},429);
  if(Number(request.headers.get('content-length')||0)>20000)return json({error:'Verzoek te lang'},413);
  let input;try{input=await request.json()}catch{return json({error:'Ongeldige JSON'},400)}
  if(JSON.stringify(input).length>20000)return json({error:'Verzoek te lang'},413);
  if(!['chat','generate'].includes(input.action))return json({error:'Ongeldige actie'},400);
  const topic=clean(input.topic||'natuurkunde',100),difficulty=clean(input.difficulty||'gemiddeld',30);
  const count=Math.min(12,Math.max(1,Number(input.count)||5));
  const prompt=input.action==='chat'
    ?`Je bent TelhasTizi AI, een behulpzame maar nauwkeurige natuurkundedocent voor Nederlandse 3 VWO leerlingen. Antwoord in helder Nederlands. Gebruik juiste formules, symbolen (Δ, ρ, Ω, m/s²) en eenheden. Geef hints bij oefenopgaven voordat je het hele antwoord verklapt. Huidig onderwerp: ${topic}. Opgave: ${clean(input.question||'geen',800)}. Je kent niet automatisch de officiële Polaris-inhoud: doe daar geen ongegronde claims over. Toon rekenstappen en controleer eenheden.`
    :`Maak ${count} nieuwe, gevarieerde rekenopgaven voor natuurkunde 3 VWO, Nederlands, over ${topic}, moeilijkheid ${difficulty}. Lever alleen valide JSON met {"questions":[...]}. Elk item heeft text (opgave), value (eindwaarde als getal), unit (SI-eenheid), formula (gebruik echte symbolen zoals F = m × a), steps (3-5 Nederlandse uitgeschreven rekenstappen met formules), mistake (veelgemaakte fout). Gebruik realistische eenvoudige getallen, correcte eenheden, en controleer de berekeningen. Geen verzonnen citaten uit Polaris. Geen markdown fences.`;
  let contents;
  if(input.action==='chat'){
    const messages=Array.isArray(input.messages)?input.messages.slice(-12).filter(m=>['user','assistant'].includes(m.role)&&typeof m.content==='string'):[];
    if(!messages.length||messages[messages.length-1].role!=='user')return json({error:'Geen vraag ontvangen'},400);
    contents=messages.map(m=>({role:m.role==='assistant'?'model':'user',parts:[{text:clean(m.content,1800)}]}));
  }else contents=[{role:'user',parts:[{text:'Maak de opgaven nu.'}]}];
  const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),25000);
  try{
    const model=process.env.GEMINI_MODEL||'gemini-2.5-flash';
    const res=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,{method:'POST',signal:controller.signal,headers:{'x-goog-api-key':process.env.GEMINI_API_KEY,'content-type':'application/json'},body:JSON.stringify({systemInstruction:{parts:[{text:prompt}]},contents,generationConfig:{temperature:input.action==='generate'?0.65:0.35,maxOutputTokens:input.action==='generate'?6000:2500,...(input.action==='generate'?{responseMimeType:'application/json'}:{})}})});
    const data=await res.json().catch(()=>({}));
    if(!res.ok){let error=res.status===429?'Gratis AI-limiet bereikt. Probeer het later opnieuw.':res.status===403||res.status===401?'Gemini API-sleutel geweigerd. Controleer de sleutel en API-toegang.':(data.error?.message||'Gemini-service tijdelijk niet beschikbaar.');return json({error:clean(error,350)},res.status===429?429:502)}
    const result=(data.candidates?.[0]?.content?.parts||[]).map(p=>p.text||'').join('').trim();
    if(!result)return json({error:'Gemini stuurde geen tekst terug.'},502);
    if(input.action==='chat')return json({reply:result.slice(0,11000)});
    let obj;try{obj=JSON.parse(result)}catch{return json({error:'Gemini gaf ongeldige vraaggegevens terug. Probeer opnieuw.'},502)}
    if(!Array.isArray(obj.questions))return json({error:'Geen vragen ontvangen.'},502);
    const questions=obj.questions.filter(q=>q&&typeof q.text==='string'&&Number.isFinite(Number(q.value))&&typeof q.unit==='string'&&typeof q.formula==='string'&&Array.isArray(q.steps)&&typeof q.mistake==='string').slice(0,count).map(q=>({text:clean(q.text,800),value:Number(q.value),unit:clean(q.unit,45),formula:clean(q.formula,160),steps:q.steps.slice(0,6).map(s=>clean(s,350)),mistake:clean(q.mistake,400)}));
    if(!questions.length)return json({error:'Geen geldige vragen ontvangen.'},502);
    return json({questions});
  }catch(e){return json({error:e.name==='AbortError'?'Gemini reageert niet op tijd. Probeer het opnieuw.':'Verbinding met Gemini mislukt.'},502)}finally{clearTimeout(timeout)}
}
export const config={path:'/.netlify/functions/ai'};
