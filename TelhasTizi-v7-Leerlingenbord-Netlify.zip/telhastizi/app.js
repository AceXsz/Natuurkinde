(()=>{'use strict';
const TOPICS=[
{id:'soorten',name:'2.1 Soorten krachten',icon:'⚖',formula:'Fz = m × g',unit:'N',
 intro:'Je leert wat de gevolgen van een kracht zijn, welke soorten krachten er bestaan en hoe je een kracht tekent.',
 definition:'Een kracht kan de vorm van een voorwerp veranderen, de snelheid veranderen en de richting veranderen. Het symbool voor kracht is F en de eenheid is newton (N).',
 method:['Schrijf de massa m in kg op.','Gebruik op aarde g = 9,8 N/kg.','Vul de formule Fz = m × g in.','Schrijf het antwoord in newton (N).'],
 pitfall:'Verwar massa (kg) niet met kracht (N).',
 sections:[
   {title:'Gevolgen van een kracht', bullets:['Een kracht kan de vorm van een voorwerp veranderen.','Een kracht kan de snelheid van een voorwerp veranderen.','Een kracht kan de richting van een voorwerp veranderen.']},
   {title:'Belangrijke krachtsoorten', bullets:['Spierkracht: kracht van je spieren op een voorwerp.','Veerkracht: kracht van een veer of elastiek.','Zwaartekracht: aantrekkingskracht van de aarde op een voorwerp.','Magnetische kracht: kracht van een magneet.','Wrijvingskracht: kracht die een beweging tegenwerkt.']},
   {title:'Een kracht tekenen', bullets:['Een kracht heeft een aangrijpingspunt, een richting en een grootte.','De pijl begint in het aangrijpingspunt.','De lengte van de pijl geeft de grootte van de kracht weer.','Met een krachtschaal, bijvoorbeeld 1 cm ≙ 10 N, vertaal je een kracht naar een pijllengte.']},
   {title:'Zwaartepunt', bullets:['Bij regelmatig gevormde voorwerpen ligt het zwaartepunt in het midden.','Bij onregelmatige voorwerpen kun je het zwaartepunt vinden door het voorwerp op te hangen en loodlijnen te tekenen.']}
 ],
 example:{title:'Voorbeeld',text:'Een voorwerp met massa 2,0 kg heeft op aarde een zwaartekracht van Fz = 2,0 × 9,8 = 19,6 N.'}
},
{id:'meten',name:'2.2 Krachten meten',icon:'🪝',formula:'Fv = C × u',unit:'N',
 intro:'Je leert hoe je een kracht meet en wat het verband is tussen de uitrekking van een veer en de veerkracht.',
 definition:'Met een krachtmeter meet je kracht. Hoe groter de kracht, hoe verder de veer uitrekt. Voor een veer geldt: Fv = C × u.',
 method:['Bepaal de uitrekking u in meter.','Lees of bereken de veerconstante C in N/m.','Vul de formule Fv = C × u in.','Controleer de eenheid: de kracht is in newton.'],
 pitfall:'Gebruik u in meter, niet in centimeter, tenzij je eerst omrekent.',
 sections:[
   {title:'Krachtmeter', bullets:['Een krachtmeter heeft een veer en een schaalverdeling.','Kies een passend meetbereik: een kleiner bereik geeft vaak een nauwkeuriger meting.']},
   {title:'Veerkracht en veerconstante', bullets:['Fv is de veerkracht in N.','C is de veerconstante in N/m.','u is de uitrekking van de veer in m.','Hoe groter C, hoe stugger de veer.']},
   {title:'Recht evenredig', bullets:['Als de kracht twee keer zo groot wordt, wordt de uitrekking ook twee keer zo groot.','In een (Fv,u)-diagram hoort daarbij een rechte lijn door de oorsprong.','De helling van die lijn is de veerconstante C.']}
 ],
 example:{title:'Voorbeeld',text:'Bij een kracht van 75 N hoort een uitrekking van 0,30 m. Dan is C = 75 / 0,30 = 250 N/m.'}
},
{id:'resulterende',name:'2.3 Resulterende kracht',icon:'➕',formula:'Fres = ΣF',unit:'N',
 intro:'Je leert wat het effect is van verschillende krachten die tegelijk op een voorwerp werken.',
 definition:'De resulterende kracht is de som van alle krachten op een voorwerp. Krachten in dezelfde richting tel je op; tegengestelde krachten trek je van elkaar af.',
 method:['Kies één richting als positief.','Tel krachten in dezelfde richting op.','Trek tegenwerkende krachten af.','Geef ook de richting van de resulterende kracht aan.'],
 pitfall:'Vergeet de richting niet: een negatieve uitkomst betekent dat de resulterende kracht de andere kant op werkt.',
 sections:[
   {title:'Resultante', bullets:['Werken krachten dezelfde kant op, dan tel je ze op.','Werken krachten tegengesteld, dan trek je af.','Als er een resulterende kracht is, kan de snelheid veranderen.']},
   {title:'Krachten in evenwicht', bullets:['Als de resulterende kracht 0 N is, zijn krachten in evenwicht.','Een stilstaand voorwerp blijft dan stilstaan.','Een voorwerp dat al beweegt, houdt dan zijn snelheid constant.']},
   {title:'Normaalkracht, spankracht en gewicht', bullets:['Op een voorwerp op tafel werkt naast zwaartekracht ook normaalkracht.','Bij een hangend voorwerp werkt naast zwaartekracht ook spankracht.','Het gewicht is de kracht die een voorwerp op zijn ondergrond of ophanging uitoefent.']}
 ],
 example:{title:'Voorbeeld',text:'Op een bobslee werken 250 N en 250 N naar voren en 70 N naar achteren. Dan is Fres = 250 + 250 − 70 = 430 N naar voren.'}
},
{id:'versnelling',name:'2.4 Kracht en versnelling',icon:'🚄',formula:'Fres = m × a',unit:'N',
 intro:'Je leert wat het verband is tussen een kracht en de versnelling van een voorwerp.',
 definition:'Versnelling is de snelheidsverandering per seconde: a = Δv / Δt. De versnelling hangt af van de resulterende kracht en van de massa: Fres = m × a.',
 method:['Bereken eerst zo nodig de versnelling met a = Δv / Δt.','Bereken daarna de resulterende kracht of gebruik een al gegeven Fres.','Gebruik Fres = m × a of a = Fres / m.','Controleer de eenheden: a in m/s², m in kg en F in N.'],
 pitfall:'Gebruik bij versnelling de verandering van snelheid Δv, niet alleen de eindsnelheid.',
 sections:[
   {title:'Versnelling', bullets:['Versnelling betekent dat de snelheid verandert.','Als de snelheid afneemt, is de versnelling negatief.','Het symbool voor versnelling is a en de eenheid is m/s².']},
   {title:'Rekenen met kracht en versnelling', bullets:['De versnelling is recht evenredig met de resulterende kracht.','De versnelling is omgekeerd evenredig met de massa.','Een grote massa geeft bij dezelfde resulterende kracht een kleinere versnelling.']},
   {title:'Rol- en luchtweerstand', bullets:['Rolweerstand en luchtweerstand werken een beweging tegen.','Om met constante snelheid te bewegen moet de spier- of motorkracht even groot zijn als de tegenwerkende krachten.','Luchtweerstand neemt toe als de snelheid groter wordt.']}
 ],
 example:{title:'Voorbeeld',text:'Een fietser rijdt 20 km/h. Met 60 N spierkracht, 15 N rolweerstand en 12 N luchtweerstand is Fres = 33 N. Bij m = 75 kg geldt a = 33 / 75 = 0,44 m/s².'}
},
{id:'veiligheid',name:'2.5 Veiligheid in het verkeer',icon:'🛡',formula:'p = F / A',unit:'Pa',
 intro:'Je leert hoe veiligheidsvoorzieningen in het verkeer de schade bij een botsing beperken.',
 definition:'Bij een botsing kun je schade beperken door de snelheid lager te maken, de botsingstijd te vergroten en de kracht over een groter oppervlak te verdelen.',
 method:['Gebruik bij een botsing indien nodig a = Δv / Δt.','Bereken dan de kracht met Fres = m × a.','Voor druk gebruik je p = F / A.','Controleer de eenheden: druk in pascal (Pa), dus N/m².'],
 pitfall:'Een kleinere druk krijg je door hetzelfde kracht-effect over een groter oppervlak te verdelen of door de botsingstijd te vergroten.',
 sections:[
   {title:'Botsing en botsingstijd', bullets:['Bij een plotselinge snelheidsverandering is een kracht nodig.','Kortere botsingstijd betekent grotere kracht.','Gordels, airbags en kreukelzones vergroten de botsingstijd.']},
   {title:'Druk en oppervlak', bullets:['Druk is kracht per oppervlakte-eenheid: p = F / A.','Een groter oppervlak geeft bij dezelfde kracht een kleinere druk.','Helmen en airbags verkleinen daarom de kans op letsel.']},
   {title:'Veiligheidsvoorzieningen', bullets:['Veiligheidsgordels rekken iets uit en vergroten zo de botsingstijd.','Airbags vergroten zowel de botsingstijd als het contactoppervlak.','Kreukelzones vervormen zodat de inzittendenruimte beter beschermd blijft.','Botsproeven worden gebruikt om krachten en vervormingen te meten.']}
 ],
 example:{title:'Voorbeeld',text:'Als op een lichaam een kracht van 1200 N werkt over een oppervlak van 0,04 m², dan is de druk p = 1200 / 0,04 = 30000 Pa.'}
}
];
const KEY='telhastizi-v5-book';const STUDENT_KEY='telhastizi-student-v1';let student=(()=>{try{return JSON.parse(localStorage.getItem(STUDENT_KEY)||'null')}catch{return null}})();let board={students:[],loading:false,error:'',shared:false};const saved=(()=>{try{return JSON.parse(localStorage.getItem(KEY)||'{}')}catch{return {}}})();let state={page:'dashboard',topic:'soorten',difficulty:'gemiddeld',mode:'oefen',count:10,questions:[],index:0,theme:saved.theme||'dark',history:saved.history||[],mistakes:saved.mistakes||[],sessions:saved.sessions||[],bookmarks:saved.bookmarks||[],chat:[],draft:saved.draft||null,config:saved.config||{},mobile:false,loading:false,notice:'',aiStatus:null,settingsTab:'general'};document.body.classList.toggle('light',state.theme==='light');
function persist(){localStorage.setItem(KEY,JSON.stringify({theme:state.theme,history:state.history.slice(-500),mistakes:state.mistakes.slice(-150),sessions:state.sessions.slice(-60),bookmarks:state.bookmarks,draft:state.questions.length?{questions:state.questions,index:state.index,mode:state.mode}:null,config:state.config}))}if(state.draft?.questions?.length){state.questions=state.draft.questions;state.index=Math.min(state.draft.index||0,state.questions.length-1);state.mode=state.draft.mode||'oefen'}
const $=s=>document.querySelector(s);const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));const rnd=(a,b)=>Math.floor(Math.random()*(b-a+1))+a;const pick=a=>a[rnd(0,a.length-1)];const fmt=n=>Number(n.toFixed(3)).toLocaleString('nl-NL',{maximumFractionDigits:3});const topic=id=>TOPICS.find(t=>t.id===id)||TOPICS[0];const isAI=()=>state.aiStatus===true;
const ICONS={leerlingen:'🏆',dashboard:'▦',chapters:'▤',practice:'✎',theory:'◈',tutor:'✧',mistakes:'↺',stats:'▥',settings:'⚙'};const nav=[['dashboard','Dashboard'],['leerlingen','Leerlingenbord'],['chapters','Hoofdstukken'],['practice','Oefenvragen'],['theory','Theorie'],['tutor','AI Tutor'],['mistakes','Mijn fouten'],['stats','Statistieken'],['settings','Instellingen']];function page(p){state.page=p;state.mobile=false;render();window.scrollTo({top:0,behavior:'smooth'})}const button=(label,fn,kind='primary',extra='')=>`<button class="btn ${kind==='primary'?'':kind} ${extra}" data-action="${fn}">${label}</button>`;function base(content){const n=state.history.length,c=state.history.filter(h=>h.correct).length;return `<div class="shell"><aside class="sidebar ${state.mobile?'open':''}"><div class="brand"><span class="brandIcon">ϟ</span>TelhasTizi</div><div class="nav">${nav.map(([id,label])=>`<button data-action="page:${id}" class="${state.page===id?'active':''}"><span class="ico">${ICONS[id]}</span>${label}</button>`).join('')}</div><div class="sideBottom"><strong>✦ 3 VWO Natuurkunde</strong>Gebaseerd op jouw boekfoto's van Hoofdstuk 2: Kracht en beweging.<div class="progress"><span style="width:${n?Math.round(c/n*100):0}%"></span></div><div style="margin-top:9px">${n} antwoorden geoefend</div></div></aside><main class="main"><header class="top"><div class="flex"><button class="btn ghost sm hamb" data-action="menu">☰</button><div class="eyebrow">TELHASTIZI / ${esc(nav.find(x=>x[0]===state.page)?.[1]||'Leren')}</div></div><div class="topRight"><span class="pill">${isAI()?'✦ Gemini AI verbonden':'◌ Offline oefenmodus'}</span><button class="btn ghost sm" data-action="theme" title="Wissel thema">${state.theme==='dark'?'☀':'☾'}</button><div class="avatar" title="Ingelogde leerling">${esc((student?.name||'L').slice(0,1).toUpperCase())}</div></div></header>${content}<footer style="padding:45px 0 0;color:var(--muted);font-size:12px">TelhasTizi • Onafhankelijk oefenplatform • Theorie en oefenvragen zijn opgebouwd uit jouw aangeleverde hoofdstukfoto's van Hoofdstuk 2.</footer></main></div>`}
function dashboard(){let n=state.history.length,ok=state.history.filter(x=>x.correct).length,streak=getStreak();return `<div class="hero"><div><span class="topicChip">✦ JOUW LEEROMGEVING</span><h1>Welkom, ${esc(student?.name||'leerling')}! 👋</h1><p>Natuurkunde begrijpen. Slimmer oefenen. Beter presteren. Bouw elke dag aan je kennis met slimme oefenvragen.</p>${button('▶ Verder leren','resume')} ${button('＋ Nieuwe oefensessie','page:practice','secondary')}</div><div class="orbit">⚛</div></div><div class="metricGrid"><div class="card metric"><span class="label">Vragen beantwoord</span><span class="miniIcon">✎</span><div class="big">${n}</div><div class="small muted">Totaal gecontroleerd</div></div><div class="card metric"><span class="label">Nauwkeurigheid</span><span class="miniIcon">◎</span><div class="big">${n?Math.round(100*ok/n):0}%</div><div class="small muted">Correcte antwoorden</div></div><div class="card metric"><span class="label">Leerreeks</span><span class="miniIcon">♨</span><div class="big">${streak} dagen</div><div class="small muted">Dagen achter elkaar</div></div><div class="card metric"><span class="label">Te herhalen</span><span class="miniIcon">↺</span><div class="big">${state.mistakes.length}</div><div class="small muted">Opgeslagen fouten</div></div></div><h2 class="sectionTitle">Ontdek onderwerpen</h2><div class="twoCol"><div class="topics">${TOPICS.slice(0,6).map(t=>topicCard(t)).join('')}</div><div class="card"><div class="spread"><h3>Je leertraject</h3><span class="topicChip">3 VWO</span></div><p class="muted small">Doe een korte sessie of oefen je fouten gericht.</p><div class="divider"></div><h3>Recente sessies</h3>${state.sessions.length?state.sessions.slice(-4).reverse().map(s=>`<div class="spread review"><span>${esc(topic(s.topic).name)}<div class="muted small">${new Date(s.time).toLocaleDateString('nl-NL')}</div></span><strong>${s.correct}/${s.count}</strong></div>`).join(''):'<div class="empty">Nog geen sessies afgerond.</div>'}<div class="divider"></div>${button('Oefen mijn fouten →','page:mistakes','secondary')}</div></div>`}
function topicCard(t){let a=state.history.filter(h=>h.topic===t.id),score=a.length?Math.round(a.filter(h=>h.correct).length/a.length*100):0;return `<button class="topic" data-action="topic:${t.id}"><div class="emoji">${t.icon}</div><strong>${esc(state.config[t.id]?.name||t.name)}</strong><small>${a.length} vragen geoefend · ${score}% juist</small><div class="progress"><span style="width:${score}%"></span></div></button>`}
function chapters(){return `<div class="pageHead"><span class="topicChip">VERKEN DE STOF</span><h1>Hoofdstukken en onderwerpen</h1><p>Hieronder staan de onderdelen van Hoofdstuk 2 uit jouw boekfoto's. Je kunt elk onderdeel apart oefenen.</p></div><div class="topics" style="grid-template-columns:repeat(auto-fit,minmax(220px,1fr))">${TOPICS.map(topicCard).join('')}</div>`}
function setup(){return `<div class="pageHead"><span class="topicChip">AAN DE SLAG</span><h1>Stel je oefensessie samen</h1><p>Kies een onderdeel uit Hoofdstuk 2. De vragen sluiten aan op de theorie uit jouw boek en verschijnen één voor één.</p></div><div class="card" style="max-width:760px"><div class="fields"><div class="field"><label>Onderwerp</label><select id="topicSelect">${TOPICS.map(t=>`<option value="${t.id}" ${state.topic===t.id?'selected':''}>${esc(state.config[t.id]?.name||t.name)}</option>`).join('')}</select></div><div class="field"><label>Moeilijkheid</label><select id="difficulty"><option value="makkelijk">Makkelijk</option><option value="gemiddeld" ${state.difficulty==='gemiddeld'?'selected':''}>Gemiddeld</option><option value="moeilijk" ${state.difficulty==='moeilijk'?'selected':''}>Moeilijk</option><option value="adaptief" ${state.difficulty==='adaptief'?'selected':''}>Adaptief</option></select></div><div class="field"><label>Aantal vragen</label><select id="count"><option value="5">5 vragen</option><option value="10" selected>10 vragen</option><option value="15">15 vragen</option><option value="20">20 vragen</option></select></div><div class="field"><label>Oefenmodus</label><select id="mode"><option value="oefen">Oefenmodus — directe feedback</option><option value="toets">Toetsmodus — feedback achteraf</option><option value="adaptief">Adaptief — wisselende moeilijkheid</option></select></div></div><div class="divider"></div><div class="note">Vragen worden lokaal gegenereerd met gecontroleerde formules. ${isAI()?'AI kan daarnaast nieuwe vragen maken.':'Met een ingestelde Netlify Gemini-functie kun je ook AI-vragen genereren.'}</div><div class="flex" style="margin-top:20px">${button('Start oefenen →','start')} ${isAI()?button('✦ Genereer met AI','startAI','secondary'):''}</div></div>`}
function makeQuestion(id,diff){
 let lvl=diff==='adaptief'?pick(['makkelijk','gemiddeld','moeilijk']):diff;
 let q={id:'q'+Date.now()+Math.random().toString(36).slice(2),topic:id,difficulty:lvl,answer:'',checked:false,correct:false,source:'offline'};
 let a,b,c,ans,unit='N',form='';
 const forceScale=pick([5,10,20]);
 switch(id){
  case 'soorten':
    if(Math.random()<0.55){
      a=rnd(1,12); ans=+(a*9.8).toFixed(1); unit='N'; form='Fz = m × g';
      q.text=`Een voorwerp heeft een massa van ${a} kg. Bereken de zwaartekracht op aarde. Gebruik g = 9,8 N/kg.`;
      q.steps=[`Gegeven: m = ${a} kg en g = 9,8 N/kg.`,`Formule: Fz = m × g.`,`Invullen: ${a} × 9,8 = ${fmt(ans)}.`,`Dus Fz = ${fmt(ans)} N.`];
      q.mistake='Zwaartekracht bereken je met massa × 9,8 N/kg.';
    } else {
      a=rnd(2,8); ans=a*forceScale; unit='N'; form='F = krachtschaal × pijllengte';
      q.text=`Bij een krachtschaal van 1 cm ≙ ${forceScale} N teken je een pijl van ${a} cm. Hoe groot is de kracht?`;
      q.steps=[`Gegeven: 1 cm stelt ${forceScale} N voor en de pijl is ${a} cm lang.`,`Berekening: ${a} × ${forceScale} = ${ans}.`,`Dus de kracht is ${ans} N.`];
      q.mistake='Vermenigvuldig de pijllengte met de krachtschaal.';
    }
    break;
  case 'meten':
    if(Math.random()<0.5){
      a=rnd(1,6)*50; b=rnd(5,30)/100; ans=+(a*b).toFixed(2); unit='N'; form='Fv = C × u';
      q.text=`Een veer heeft een veerconstante van ${a} N/m en een uitrekking van ${fmt(b)} m. Bereken de veerkracht.`;
      q.steps=[`Gegeven: C = ${a} N/m en u = ${fmt(b)} m.`,`Formule: Fv = C × u.`,`Invullen: ${a} × ${fmt(b)} = ${fmt(ans)}.`,`Dus Fv = ${fmt(ans)} N.`];
      q.mistake='Gebruik de formule Fv = C × u en reken u in meter.';
    } else {
      a=rnd(20,120); b=pick([0.1,0.2,0.25,0.3,0.4]); ans=+(a/b).toFixed(1); unit='N/m'; form='C = Fv / u';
      q.text=`Bij een veerkracht van ${a} N rekt een veer ${fmt(b)} m uit. Bereken de veerconstante.`;
      q.steps=[`Gegeven: Fv = ${a} N en u = ${fmt(b)} m.`,`Formule omgeschreven: C = Fv / u.`,`Invullen: ${a} / ${fmt(b)} = ${fmt(ans)}.`,`Dus C = ${fmt(ans)} N/m.`];
      q.mistake='De veerconstante bereken je door kracht te delen door uitrekking.';
    }
    break;
  case 'resulterende':
    if(Math.random()<0.45){
      a=rnd(80,250); b=rnd(80,250); c=rnd(20,100); ans=a+b-c; unit='N'; form='Fres = F1 + F2 − Ftegen';
      q.text=`Twee krachten van ${a} N en ${b} N werken naar voren. Een wrijvingskracht van ${c} N werkt naar achteren. Bereken de resulterende kracht.`;
      q.steps=[`Krachten naar voren: ${a} N en ${b} N. Tegenwerkende kracht: ${c} N.`,`Formule: Fres = ${a} + ${b} − ${c}.`,`Uitkomst: Fres = ${ans} N naar voren.`];
      q.mistake='Tel krachten in dezelfde richting op en trek de tegenwerkende kracht af.';
    } else if(Math.random()<0.75){
      a=rnd(1,20); ans=+(a*9.8).toFixed(1); unit='N'; form='Fz = m × g';
      q.text=`Een voorwerp met massa ${a} kg hangt stil aan een touw. Hoe groot is de spankracht?`;
      q.steps=[`Het voorwerp hangt stil, dus de krachten zijn in evenwicht.`,`Daarom geldt: spankracht = zwaartekracht.`,`Fz = ${a} × 9,8 = ${fmt(ans)} N.`,`Dus Fspan = ${fmt(ans)} N.`];
      q.mistake='Bij evenwicht is de spankracht even groot als de zwaartekracht.';
    } else {
      a=rnd(1,20); ans=+(a*9.8).toFixed(1); unit='N'; form='gewicht = kracht op de ondergrond';
      q.text=`Een boek met massa ${a} kg ligt stil op een tafel. Bereken het gewicht van het boek.`;
      q.steps=[`Het gewicht is de kracht die het boek op de tafel uitoefent.`,`Bij stil liggen is het gewicht even groot als de zwaartekracht.`,`Fz = ${a} × 9,8 = ${fmt(ans)} N.`,`Dus het gewicht is ${fmt(ans)} N.`];
      q.mistake='Gewicht is hier gelijk aan de zwaartekracht op het boek.';
    }
    break;
  case 'versnelling':
    if(Math.random()<0.34){
      a=rnd(10,30); b=rnd(2,8); c=a+rnd(5,25); ans=+(((c-a)/b).toFixed(2)); unit='m/s²'; form='a = Δv / Δt';
      q.text=`De snelheid van een trein neemt toe van ${a} m/s naar ${c} m/s in ${b} s. Bereken de versnelling.`;
      q.steps=[`Gegeven: vbegin = ${a} m/s, veind = ${c} m/s en Δt = ${b} s.`,`Δv = ${c} − ${a} = ${c-a} m/s.`,`Formule: a = Δv / Δt = ${c-a} / ${b}.`,`Dus a = ${fmt(ans)} m/s².`];
      q.mistake='Versnelling is de verandering van snelheid gedeeld door de tijd.';
    } else if(Math.random()<0.67){
      a=rnd(20,120); b=rnd(2,10); ans=a*b; unit='N'; form='Fres = m × a';
      q.text=`Een voorwerp met massa ${a} kg versnelt met ${b} m/s². Bereken de resulterende kracht.`;
      q.steps=[`Gegeven: m = ${a} kg en a = ${b} m/s².`,`Formule: Fres = m × a.`,`Invullen: ${a} × ${b} = ${ans}.`,`Dus Fres = ${ans} N.`];
      q.mistake='Vermenigvuldig massa en versnelling.';
    } else {
      a=rnd(60,120); b=rnd(40,90); c=rnd(10,30); ans=+(((b-c)/a).toFixed(2)); unit='m/s²'; form='a = Fres / m';
      q.text=`Een fietser met totale massa ${a} kg levert ${b} N spierkracht. De tegenwerkende krachten samen zijn ${c} N. Bereken de versnelling.`;
      q.steps=[`Resulterende kracht: Fres = ${b} − ${c} = ${b-c} N.`,`Formule: a = Fres / m.`,`Invullen: ${b-c} / ${a} = ${fmt(ans)}.`,`Dus a = ${fmt(ans)} m/s².`];
      q.mistake='Bereken eerst de resulterende kracht, daarna de versnelling.';
    }
    break;
  case 'veiligheid':
    if(Math.random()<0.5){
      a=rnd(40,90); b=rnd(10,30); c=pick([0.2,0.4,0.5,0.8,1.0]); ans=+((a*b/c).toFixed(1)); unit='N'; form='Fres = m × Δv / Δt';
      q.text=`Een persoon met massa ${a} kg komt bij een botsing van ${b} m/s tot stilstand in ${fmt(c)} s. Bereken de gemiddelde kracht tijdens de vertraging.`;
      q.steps=[`Gegeven: m = ${a} kg, Δv = ${b} m/s en Δt = ${fmt(c)} s.`,`Formule: Fres = m × Δv / Δt.`,`Invullen: ${a} × ${b} / ${fmt(c)} = ${fmt(ans)}.`,`Dus de gemiddelde kracht is ${fmt(ans)} N.`];
      q.mistake='Gebruik de snelheidsverandering gedeeld door de botsingstijd.';
    } else {
      a=rnd(400,2500); b=pick([0.02,0.04,0.05,0.08,0.1]); ans=+(a/b).toFixed(1); unit='Pa'; form='p = F / A';
      q.text=`Op een oppervlak van ${fmt(b)} m² werkt een kracht van ${a} N. Bereken de druk.`;
      q.steps=[`Gegeven: F = ${a} N en A = ${fmt(b)} m².`,`Formule: p = F / A.`,`Invullen: ${a} / ${fmt(b)} = ${fmt(ans)}.`,`Dus p = ${fmt(ans)} Pa.`];
      q.mistake='Druk is kracht gedeeld door oppervlakte.';
    }
    break;
 }
 q.value=ans; q.unit=unit; q.formula=form; q.steps=q.steps||[];
 if(['N','Pa','m/s²','N/m'].includes(unit) && Math.random()>.78){
   let wrong=[ans*2,ans/2,ans+(Math.abs(ans)>10?10:1)].map(v=>+v.toFixed(2)).filter(v=>Math.abs(v-ans)>0.001);
   q.type='choice'; q.options=[ans,...wrong].sort(()=>Math.random()-.5).map(v=>fmt(v)+' '+unit);
 } else q.type='numeric';
 return q
}
function exercise(){let q=state.questions[state.index];if(!q)return setup();let pct=(state.index+1)/state.questions.length*100,disabled=state.mode==='toets'&&q.checked;return `<div class="questionWrap"><div class="spread"><div><span class="topicChip">${esc(topic(q.topic).name)}</span><span class="small muted" style="margin-left:10px">${esc(q.difficulty||'gemiddeld')} · ${state.mode==='toets'?'Toetsmodus':'Oefenmodus'}</span></div>${button('✕ Stoppen','stop','ghost','sm')}</div><div class="spread" style="margin-top:20px"><strong>Vraag ${state.index+1} van ${state.questions.length}</strong><span class="muted small">${Math.round(pct)}% van deze sessie</span></div><div class="progress" style="margin:12px 0 21px;height:9px"><span style="width:${pct}%"></span></div><div class="questionCard"><div class="spread"><span class="eyebrow">BEREKEN & BEGRIJP</span><button class="btn ghost sm" data-action="bookmark">${state.bookmarks.includes(q.id)?'★ Bewaard':'☆ Bewaar vraag'}</button></div><h2>${esc(q.text)}</h2>${q.type==='choice'?`<div class="choices">${q.options.map((x,i)=>`<button class="choice ${q.answer===x?'selected':''}" data-action="choice:${i}" ${disabled?'disabled':''}><strong style="margin-right:12px">${'ABCD'[i]}</strong>${esc(x)}</button>`).join('')}</div>`:`<div class="field"><label>Jouw antwoord (met eenheid, bijvoorbeeld: 15 ${esc(q.unit)})</label><input id="answer" class="answerInput" inputmode="decimal" autocomplete="off" placeholder="Typ je antwoord..." value="${esc(q.answer||'')}" ${disabled?'disabled':''}>${!disabled?symbolPad('answer'): ''}</div>`}<div class="flex" style="margin-top:22px">${!q.checked||state.mode!=='toets'?button(q.checked?'Opnieuw controleren':'Controleer antwoord','check'):''}${state.mode!=='toets'?button('Bekijk theorie','theoryCurrent','secondary'):''}${state.mode!=='toets'?button('Geef een hint','hint','ghost'):''}</div>${q.checked&&state.mode!=='toets'?feedback(q):''}${q.hint&&state.mode!=='toets'?`<div class="note" style="margin-top:18px">💡 Hint: ${esc(q.formula)}</div>`:''}</div><div class="questionNav">${button('← Vorige vraag','prev','secondary',state.index===0?'': '')}<span class="small muted">← → toetsen</span>${state.index===state.questions.length-1?button('Sessie afronden ✓','finish'):button('Volgende vraag →','next')}</div><div class="small muted" style="text-align:center;margin-top:19px">Je antwoord wordt automatisch op dit apparaat opgeslagen.</div></div>`}
function feedback(q){return `<div class="feedback ${q.correct?'':'bad'}"><h3>${q.correct?'✓ Helemaal goed!':'✕ Niet helemaal goed!'}</h3><div><strong>Jouw antwoord:</strong> ${esc(q.submitted||'—')}</div><div><strong>Goed antwoord:</strong> ${fmt(q.value)} ${esc(q.unit)}</div>${!q.correct?`<p><strong>Wat ging er mis?</strong> ${esc(q.issue||q.mistake)}</p>`:''}<strong>Stap voor stap</strong><ol>${q.steps.map(s=>`<li>${esc(s)}</li>`).join('')}</ol><div class="note">Onthoud: ${esc(q.mistake)}</div><div class="flex" style="margin-top:14px">${button('Leg simpeler uit','simpler','secondary','sm')}${button('Vergelijkbare vraag','similar','secondary','sm')}${button('Waarom fout?','why','ghost','sm')}</div></div>`}
// A physics-aware answer parser: Dutch commas, scientific notation, and units.
function parseAnswer(raw){
  let str=String(raw??'').trim().replace(/\u2212/g,'-').replace(/[\u00a0\u202f]/g,' ');
  // Scientific notation: 1,2 × 10^3, 1.2 · 10³, and 1.2e3.
  const supers={'⁰':'0','¹':'1','²':'2','³':'3','⁴':'4','⁵':'5','⁶':'6','⁷':'7','⁸':'8','⁹':'9','⁻':'-','⁺':'+'};
  str=str.replace(/[⁰¹²³⁴⁵⁶⁷⁸⁹⁻⁺]+/g,m=>'^'+[...m].map(c=>supers[c]).join(''));
  str=str.replace(/([\d.,]+)\s*[×·*]\s*10\s*\^\s*\(?\s*([+-]?\d+)\s*\)?/gi,'$1e$2');
  let m=str.match(/^\s*([+-]?(?:(?:\d{1,3}(?:[ .]\d{3})+|\d+)(?:[.,]\d+)?|[.,]\d+)(?:e[+-]?\d+)?)\s*(.*?)\s*$/i);
  if(!m)return {valid:false,value:NaN,unit:''};
  let number=m[1].replace(/\s/g,'');
  if(number.includes(',') && number.includes('.')){
    const decimal=number.lastIndexOf(',')>number.lastIndexOf('.')?',':'.';
    number=decimal===','?number.replace(/\./g,'').replace(',','.'):number.replace(/,/g,'');
  }else if(number.includes(',')){
    number=number.replace(/,/g,'.');
  }else if(/^[+-]?\d{1,3}(?:\.\d{3})+$/.test(number)){
    number=number.replace(/\./g,'');
  }
  const value=Number(number);return {valid:Number.isFinite(value),value,unit:m[2]};
}
function canonicalUnit(raw){return String(raw??'').trim().toLowerCase().replace(/\s/g,'').replace(/[³]/g,'3').replace(/²/g,'2').replace(/[·⋅]/g,'').replace(/\^([23])/g,'$1').replace(/°/g,'°').replace(/−/g,'-').replace(/ohm|ω/g,'Ω').replace(/Ω/g,'Ω');}
function evaluateAnswer(raw,q){
  const parsed=parseAnswer(raw),expected=Number(q.value);
  if(!parsed.valid||!Number.isFinite(expected))return {correct:false,issue:'Ik kan dit getal niet lezen. Gebruik bijvoorbeeld 19,62 N of 1,962 × 10¹ N.'};
  const unit=canonicalUnit(q.unit),entered=canonicalUnit(parsed.unit);
  let multiplier=1,validUnit=true;
  const aliases={ 'm/s':['m/s','ms-1','m/s1'], 'kg/m3':['kg/m3','kgm-3'], 'j':['j','joule'], 'n':['n','newton'], 'v':['v','volt'], 'Ω':['Ω'], 'w':['w','watt'], 'a':['a','ampere','ampère'], 'pa':['pa','pascal'] };
  if(entered){
    if((aliases[unit]||[unit]).includes(entered))multiplier=1;
    else if(unit==='j'&&entered==='kj')multiplier=1000;
    else if(unit==='j'&&entered==='mj')multiplier=1000000;
    else if(unit==='m/s'&&(entered==='km/h'||entered==='km/u'))multiplier=1/3.6;
    else if(unit==='kg/m3'&&(entered==='g/cm3'||entered==='g/cm³'))multiplier=1000;
    else if(unit==='n'&&entered==='kn')multiplier=1000;
    else if(unit==='v'&&entered==='mv')multiplier=0.001;
    else validUnit=false;
  }
  const actual=parsed.value*multiplier;
  const good=Math.abs(actual-expected)<=Math.max(0.01,Math.abs(expected)*0.005);
  return {correct:good&&validUnit,issue:!validUnit?`De eenheid '${parsed.unit}' komt niet overeen met ${q.unit}. Controleer de eenheid.`:!good?`Je antwoord is ${parsed.value} ${parsed.unit||q.unit}; verwacht wordt ${fmt(expected)} ${q.unit}. Controleer je formule, berekening en omrekening.`:null};
}
function answerValue(s){return parseAnswer(s).value}
function unitOk(s,q){return evaluateAnswer(s,q).issue?.startsWith('De eenheid')!==true}
function check(){let q=state.questions[state.index];if(!q)return;if(q.type!=='choice')q.answer=$('#answer')?.value??q.answer;if(!String(q.answer).trim()){alert('Vul eerst een antwoord in.');return}q.submitted=q.answer;const assessment=evaluateAnswer(q.answer,q);q.correct=assessment.correct;q.issue=assessment.issue;q.checked=true;q.checkedAt=Date.now();let entry={id:q.id,topic:q.topic,correct:q.correct,time:new Date().toISOString(),answer:q.submitted,expected:q.value,unit:q.unit,text:q.text};let ix=state.history.findIndex(x=>x.id===q.id);if(ix<0)state.history.push(entry);else state.history[ix]=entry;if(!q.correct){let idx=state.mistakes.findIndex(m=>m.question.id===q.id);let m={question:{...q,answer:'',checked:false,submitted:'',hint:false},date:Date.now(),due:Date.now()+86400000,interval:1};if(idx<0)state.mistakes.push(m);else state.mistakes[idx]=m}else{state.mistakes=state.mistakes.filter(m=>m.question.id!==q.id)}persist();render();syncProgress()}
function review(){return `<div class="pageHead"><span class="topicChip">HERHAAL SLIM</span><h1>Mijn fouten</h1><p>Oefen vragen opnieuw en verstevig wat je lastig vindt.</p></div><div class="card">${state.mistakes.length?`<div class="spread"><strong>${state.mistakes.length} vragen om te herhalen</strong>${button('Oefen mijn fouten →','reviewStart')}</div><div class="divider"></div>${state.mistakes.slice().reverse().map(m=>`<div class="review"><div class="small muted">${esc(topic(m.question.topic).name)} · ${new Date(m.date).toLocaleDateString('nl-NL')}</div><strong>${esc(m.question.text)}</strong><div class="muted small">Herhaling gepland: ${new Date(m.due).toLocaleDateString('nl-NL')}</div></div>`).join('')}`:'<div class="empty">🎉 Nog geen fouten opgeslagen! Ga oefenen om je voortgang op te bouwen.</div>'}</div>`}

const PHYSICS_SYMBOLS=[
 ['Δ','delta','Verschil of verandering','ΔT = T₂ − T₁'],['ρ','rho','Dichtheid','ρ = m / V'],['λ','lambda','Golflengte','v = f × λ'],['μ','mu','Wrijvingscoëfficiënt (in andere context ook micro)','Fᵥ = μ × Fₙ'],['Ω','omega','Ohm, eenheid van weerstand','R = 12 Ω'],['°','graad','Hoek of temperatuur','20 °C'],['²','kwadraat','Tweede macht','m²'],['³','kubiek','Derde macht','m³'],['√','wortel','Vierkantswortel','√25 = 5'],['×','maal','Vermenigvuldigen','F = m × a'],['÷','gedeeld door','Delen','20 ÷ 4 = 5'],['≈','ongeveer gelijk','Afronding','π ≈ 3,14'],['≠','niet gelijk','Waarden zijn verschillend','2 ≠ 3'],['≤','kleiner of gelijk','Vergelijking','v ≤ 50'],['≥','groter of gelijk','Vergelijking','t ≥ 0'],['π','pi','Wiskundige constante','π ≈ 3,14159'],['∞','oneindig','Geen eindige grens','∞'],['θ','theta','Hoek','θ = 30°'],['α','alpha','Hoek of andere grootheid','α = 45°'],['Σ','sigma','Som van termen','ΣF = 0 N'],['±','plus of min','Twee mogelijke tekens of onzekerheid','5 ± 0,2'],['→','pijl','Richting of overgang','kracht →'],['₁','subscript 1','Index onderaan','T₁'],['₂','subscript 2','Index onderaan','T₂'],['ₙ','subscript n','Index onderaan','Fₙ'],['·','maalpunt','Vermenigvuldigen','N·m'],['%','procent','Honderdste deel','25%'],['¹⁄₂','een half','Breuk','¹⁄₂ × m × v²']
];
const TOPIC_SYMBOLS={
 soorten:[['F','kracht','N'],['Fz','zwaartekracht','N'],['m','massa','kg'],['g','zwaarteveldsterkte','N/kg']],
 meten:[['Fv','veerkracht','N'],['C','veerconstante','N/m'],['u','uitrekking','m']],
 resulterende:[['Fres','resulterende kracht','N'],['Fn','normaalkracht','N'],['Fs','spankracht','N'],['Fz','zwaartekracht','N']],
 versnelling:[['a','versnelling','m/s²'],['Δv','snelheidsverandering','m/s'],['Δt','tijdsduur','s'],['Fres','resulterende kracht','N'],['m','massa','kg']],
 veiligheid:[['Fres','kracht','N'],['Δv','snelheidsverandering','m/s'],['Δt','botsingstijd','s'],['p','druk','Pa'],['A','oppervlakte','m²']]
};
function prettyFormula(x){
 return esc(x)
  .replace(/Fres/g,'F<sub>res</sub>')
  .replace(/Fz/g,'F<sub>z</sub>')
  .replace(/Fv/g,'F<sub>v</sub>')
  .replace(/Fn/g,'F<sub>n</sub>')
  .replace(/Fs/g,'F<sub>s</sub>')
  .replace(/Δt/g,'Δt')
  .replace(/Δv/g,'Δv')
  .replace(/m²/g,'m<sup>2</sup>')
  .replace(/m³/g,'m<sup>3</sup>')
  .replace(/m\/s²/g,'m/s<sup>2</sup>');
}

function symbolPad(target){return `<div class="symbolPad" aria-label="Wiskundige en natuurkundige symbolen"><div class="small muted">Klik op een symbool om het in te voegen · <a href="#" data-action="symbols" class="symbolLink">Betekenissen bekijken</a></div><div class="symbolKeys">${PHYSICS_SYMBOLS.map(([v,n])=>`<button type="button" class="symbolKey" title="${esc(n)}" aria-label="Voeg ${esc(n)} in" data-insert="${esc(v)}" data-target="${target}">${esc(v)}</button>`).join('')}</div></div>`}
function symbolGuide(){let selected=TOPIC_SYMBOLS[state.topic]||[];return `<section class="card theoryBlock" style="margin-top:20px"><span class="topicChip">SYMBOLEN & EENHEDEN</span><h2>Wat betekenen de letters?</h2><p>Een letter staat voor een natuurkundige grootheid. De betekenis hangt af van de formule.</p><div class="symbolTable"><div class="symbolRow heading"><b>Symbool</b><b>Betekenis</b><b>Eenheid</b></div>${selected.map(([sym,meaning,unit])=>`<div class="symbolRow"><strong class="symLarge">${prettyFormula(sym)}</strong><span>${esc(meaning)}</span><span>${prettyFormula(unit)}</span></div>`).join('')}</div><h3>Symbolenwoordenboek</h3><label for="symbolSearch" class="small muted">Zoek op teken of betekenis</label><input id="symbolSearch" class="symbolSearch" placeholder="Bijv. delta, wortel, ohm, Ω, Δ..." autocomplete="off"><div class="symbolDictionary" id="symbolDictionary">${PHYSICS_SYMBOLS.map(([v,n,desc,example])=>`<div class="symbolDefinition" data-symbol-search="${esc([v,n,desc,example].join(' ').toLowerCase())}"><span class="symLarge">${esc(v)}</span><div><strong>${esc(n)}</strong><div class="small muted">${esc(desc)}</div><div class="small">${prettyFormula(example)}</div></div></div>`).join('')}</div><p class="small muted">Let op: symbolen zoals μ of α kunnen per hoofdstuk iets anders betekenen. Controleer de definitie bij jouw formule.</p></section>`}

function theory(){let t=topic(state.topic),l=LESSONS[state.topic];return `<div class="pageHead"><span class="topicChip">POLARIS 3 VWO · HOOFDSTUK 2</span><h1>Uitgebreide theorielessen</h1><p>Begrijp de stof stap voor stap. De uitleg volgt de inhoud en volgorde van de foto’s die je hebt gedeeld, met eigen voorbeelden en tekeningen.</p></div><div class="flex chapterTabs">${TOPICS.map(x=>`<button class="btn ${x.id===state.topic?'':'secondary'} sm" data-action="theory:${x.id}">${esc(x.name)}</button>`).join('')}</div><div class="lessonLayout"><article class="card theoryBlock longLesson"><span class="topicChip">${esc(t.name)}</span><h2>${esc(t.name)}</h2><div class="lessonGoal"><b>Leerdoel</b><p>${esc(l.goal)}</p></div>${l.blocks.map((b,i)=>`<section class="lessonSection" id="lesson${i+1}"><span class="sectionIndex">ONDERDEEL ${i+1} VAN ${l.blocks.length}</span><h3>${esc(b.heading)}</h3>${b.body}</section>`).join('')}<section class="lessonSection"><span class="sectionIndex">UITGEWERKTE BEREKENINGEN</span><h3>Zo pak je opgaven aan</h3>${l.examples.map(ex=>`<div class="workedExample"><h4>${esc(ex.title)}</h4><ol>${ex.steps.map(st=>`<li>${esc(st)}</li>`).join('')}</ol></div>`).join('')}</section><section class="lessonSection"><h3>Controleer of je het begrijpt</h3><p class="small muted">Denk eerst zelf na en open daarna het antwoord.</p>${l.quiz.map((qa,i)=>`<details class="knowledgeCheck"><summary>${i+1}. ${esc(qa[0])}</summary><div>${esc(qa[1])}</div></details>`).join('')}</section><div class="note">⚠ Veelgemaakte fout: ${esc(t.pitfall)}</div><div style="margin-top:24px">${button('▶ Oefen deze paragraaf','practiceTopic')}</div></article><aside class="lessonAside"><div class="card theoryBlock"><span class="topicChip">FORMULEBLAD</span><h3>${esc(t.name)}</h3><div class="formula">${prettyFormula(t.formula)}</div><h3>Rekenstappen</h3><ol>${t.method.map(x=>`<li>${esc(x)}</li>`).join('')}</ol><div class="divider"></div><h3>Andere formules</h3>${TOPICS.filter(x=>x.id!==t.id).map(x=>`<div class="review"><div class="small muted">${esc(x.name)}</div><strong>${prettyFormula(x.formula)}</strong></div>`).join('')}</div></aside></div>${symbolGuide()}`}
function stats(){let all=state.history,acc=all.length?Math.round(all.filter(h=>h.correct).length/all.length*100):0;return `<div class="pageHead"><span class="topicChip">JOUW RESULTATEN</span><h1>Statistieken</h1><p>Bekijk welke onderwerpen goed gaan en welke extra aandacht verdienen.</p></div><div class="metricGrid"><div class="card metric"><div class="label">Antwoorden</div><div class="big">${all.length}</div></div><div class="card metric"><div class="label">Juist</div><div class="big">${acc}%</div></div><div class="card metric"><div class="label">Sessies</div><div class="big">${state.sessions.length}</div></div><div class="card metric"><div class="label">Leerreeks</div><div class="big">${getStreak()}</div></div></div><div class="card" style="margin-top:22px"><h3>Goed-percentage per onderwerp</h3><div class="barChart">${TOPICS.map(t=>{let a=all.filter(h=>h.topic===t.id),p=a.length?Math.round(a.filter(x=>x.correct).length/a.length*100):0;return `<div class="barRow"><span>${esc(t.name)}</span><div class="statBar"><span style="width:${p}%"></span></div><span>${p}%</span></div>`}).join('')}</div></div>`}
function getStreak(){let days=[...new Set(state.history.map(h=>h.time.slice(0,10)))].sort().reverse(),count=0,d=new Date();for(let i=0;i<days.length;i++){let dt=new Date(d.getFullYear(),d.getMonth(),d.getDate()-i).toISOString().slice(0,10);if(days[i]===dt)count++;else if(i===0){d.setDate(d.getDate()-1);i--;continue}else break}return count}
function tutor(){return `<div class="pageHead"><span class="topicChip">✦ TELHASTIZI AI</span><h1>Stel je vragen aan de tutor</h1><p>Vraag om hulp bij formules, berekeningen of een lastig begrip.</p></div><div class="card" style="max-width:870px"><div class="note">${isAI()?'AI-assistent verbonden. Controleer belangrijke antwoorden altijd zelf.':'AI is niet geconfigureerd op deze deployment. Je kunt wel offline theorie en oefeningen gebruiken.'}</div><div class="chat" id="chat">${state.chat.length?state.chat.map(m=>`<div class="message ${m.role==='user'?'me':''}">${esc(m.content)}</div>`).join(''):'<div class="empty">✧ Waarmee kan ik je helpen? Bijvoorbeeld: “Leg de wet van Ohm uit”.</div>'}</div><div class="field"><label>Jouw vraag</label><textarea id="chatInput" placeholder="Bijvoorbeeld: wanneer gebruik ik F = m × a?" ${!isAI()?'disabled':''}></textarea>${isAI()?symbolPad('chatInput'): ''}</div><div style="margin-top:13px">${button(state.loading?'Bezig...':'Verstuur vraag →','send','primary',state.loading||!isAI()?'':'')}</div></div>`}
function settings(){return `<div class="pageHead"><span class="topicChip">PERSONALISEER</span><h1>Instellingen</h1><p>Stel je voorkeuren in en beheer eigen hoofdstuktitels.</p></div><div class="card" style="max-width:760px"><h3>Weergave</h3><div class="spread"><span>Huidige modus: ${state.theme==='dark'?'Donker':'Licht'}</span>${button('Wissel thema','theme','secondary')}</div><div class="divider"></div><h3>Eigen hoofdstuktitels</h3><p class="muted small">Pas de namen aan je eigen Polaris-boek aan. Voorbeeldinhoud blijft voorlopig gekoppeld aan het oorspronkelijke onderwerp.</p>${TOPICS.map(t=>`<div class="field" style="margin-bottom:12px"><label>${esc(t.name)}</label><input data-config="${t.id}" value="${esc(state.config[t.id]?.name||t.name)}" maxlength="80"></div>`).join('')}${button('Opslaan','saveConfig')}<div class="divider"></div><h3>Gegevens</h3><p class="muted small">Jouw voortgang wordt lokaal in deze browser bewaard, niet in een online account.</p>${button('Wis alle voortgang','clear','ghost')}</div>`}
function finish(){let qs=state.questions,c=qs.filter(q=>q.checked&&q.correct).length,answered=qs.filter(q=>q.checked).length;return `<div class="pageHead"><span class="topicChip">SESSIE AFGEROND</span><h1>Goed gedaan! 🎉</h1><p>Je hebt een oefensessie afgerond. Bekijk je resultaten hieronder.</p></div><div class="hero" style="min-height:160px"><div><span class="eyebrow">RESULTAAT</span><h1>${c} / ${qs.length} goed</h1><p>${Math.round(c/qs.length*100)}% correct · Cijfer: ${(1+9*c/qs.length).toFixed(1).replace('.',',')} / 10 ${state.mode==='toets'?'(indicatief)':''}</p></div><div class="orbit">✦</div></div><div class="card" style="margin-top:20px"><h3>Antwoorden bekijken</h3>${qs.map((q,i)=>`<div class="review"><div class="small muted">Vraag ${i+1} · ${esc(topic(q.topic).name)}</div><strong>${esc(q.text)}</strong><div style="color:${q.checked?(q.correct?'var(--green)':'var(--red)'):'var(--muted)'}">${q.checked?(q.correct?'✓ Correct':'✕ Onjuist'):'Niet beantwoord'} · ${esc(q.submitted||'—')}</div><div class="small muted">Goed: ${fmt(q.value)} ${esc(q.unit)}</div>${state.mode==='toets'?`<div class="small muted">${esc(q.steps.join(' · '))}</div>`:''}</div>`).join('')}<div class="flex" style="margin-top:20px">${button('Nog een sessie','page:practice')}${button('Mijn fouten oefenen','page:mistakes','secondary')}</div></div>`}

function welcomeScreen(){
 return `<main class="joinPage"><section class="joinCard"><div class="brand" style="font-size:30px;justify-content:center"><span class="brandIcon">ϟ</span> TelhasTizi</div><div class="topicChip">3 VWO NATUURKUNDE</div><h1>Welkom! Hoe heet jij?</h1><p>Vul eerst je naam of een bijnaam in. Je resultaten komen op het <strong>Leerlingenbord</strong> te staan, zodat klasgenoten kunnen zien hoeveel je geoefend hebt.</p><div class="field"><label for="studentName">Jouw weergavenaam (verplicht)</label><input id="studentName" maxlength="32" minlength="2" autocomplete="nickname" placeholder="Bijv. Thien of PhysicsPro"></div><p class="small muted">Gebruik liever geen volledige achternaam. Je naam en oefenstatistieken zijn zichtbaar voor iedereen die het leerlingenbord bezoekt. Je antwoorden zelf worden niet gepubliceerd.</p><button class="btn" data-action="register" style="width:100%;margin-top:12px">Start met leren →</button><div id="joinError" class="small" role="status" style="color:var(--red);margin-top:12px"></div></section></main>`
}
function leerlingen(){let a=board.students;const max=Math.max(1,...a.map(x=>Number(x.answered)||0));return `<div class="pageHead"><span class="topicChip">🏆 SAMEN LEREN</span><h1>Leerlingenbord</h1><p>Bekijk hoeveel vragen leerlingen geoefend hebben, hoeveel ze goed hadden en hun vooruitgang per paragraaf.</p></div>
 <div class="card"><div class="spread"><div><h3 style="margin:0">${a.length} leerlingen</h3><p class="small muted">${board.shared?'Gedeeld bord · zichtbaar op andere apparaten':'Gedeeld bord nog niet verbonden'}</p></div>${button('↻ Vernieuwen','refreshBoard','secondary')}</div>
 ${board.loading?'<div class="empty">Leerlingen worden geladen…</div>':board.error?`<div class="note">${esc(board.error)}<div class="small muted">Voor een echt gedeeld bord moet je Supabase koppelen via de stappen in README.md.</div></div>`:a.length?`<div class="leaderboard">${a.map((x,i)=>{let n=Number(x.answered)||0,correct=Number(x.correct)||0,rate=n?Math.round(100*correct/n):0;return `<div class="studentRow"><div class="studentRank">${i<3?['🥇','🥈','🥉'][i]:i+1}</div><div class="studentDetails"><strong>${esc(x.display_name)} ${x.id===student?.id?'(jij)':''}</strong><div class="small muted">${n} vragen · ${correct} goed · ${rate}% juist · ${Number(x.sessions)||0} sessies</div><div class="progress" style="margin-top:7px"><span style="width:${Math.min(100,n/max*100)}%"></span></div><details><summary class="small muted">Voortgang per paragraaf</summary>${TOPICS.map(t=>{let r=x.topics?.[t.id]||{};return `<div class="small muted">${esc(t.name)}: ${Number(r.answered)||0} vragen · ${Number(r.correct)||0} goed</div>`}).join('')}</details></div></div>`}).join('')}</div>`:'<div class="empty">Nog geen leerlingen. Begin met oefenen!</div>'}</div>
 <p class="small muted" style="margin-top:16px">Het bord toont oefenstatistieken, geen officiële cijfers. Namen en voortgang zijn zichtbaar voor bezoekers van de website.</p>`}
function totals(){let history=state.history,topics={};for(const t of TOPICS){const h=history.filter(x=>x.topic===t.id);topics[t.id]={answered:h.length,correct:h.filter(x=>x.correct).length}}return {answered:history.length,correct:history.filter(x=>x.correct).length,sessions:state.sessions.length,topics}}
async function boardCall(body){let r=await fetch('/.netlify/functions/leerlingen',{method:body?'POST':'GET',headers:{'content-type':'application/json'},body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(9000)});let d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||'Geen verbinding met het leerlingenbord');return d}
async function registerStudent(){let input=document.getElementById('studentName'),name=input?.value.trim().replace(/\s+/g,' '),err=document.getElementById('joinError');if(!name||name.length<2||name.length>32){if(err)err.textContent='Typ een naam van 2 tot 32 tekens.';return}let btn=document.querySelector('[data-action="register"]');if(btn)btn.disabled=true;
 try{let d=await boardCall({action:'register',name});student={id:d.id,token:d.token,name:d.display_name};localStorage.setItem(STUDENT_KEY,JSON.stringify(student));state.page='dashboard';render();syncProgress();}
 catch(e){if(err)err.textContent=e.message+' De aanmelding vereist een verbinding met de gedeelde database.';if(btn)btn.disabled=false}}
async function loadBoard(force=false){if(board.loading)return;board.loading=true;board.error='';render();try{let data=await boardCall();board.students=data.students||[];board.shared=true}catch(e){board.error=e.message;board.shared=false}finally{board.loading=false;if(state.page==='leerlingen')render()}}
let syncBusy=false;async function syncProgress(){if(!student?.token||syncBusy)return;syncBusy=true;try{await boardCall({action:'progress',id:student.id,token:student.token,...totals()})}catch(e){console.warn('Leerlingenbord sync:',e.message)}finally{syncBusy=false}}
function render(){if(!student?.name){$('#app').innerHTML=welcomeScreen();return}let inner=({leerlingen:leerlingen,dashboard,chapters,practice:()=>state.questions.length?exercise():setup(),theory,tutor,mistakes:review,stats,settings,finish})[state.page]?.()||dashboard();$('#app').innerHTML=base(inner);if(state.page==='tutor'){let c=$('#chat');if(c)c.scrollTop=c.scrollHeight}}
function start(local=true){state.topic=$('#topicSelect')?.value||state.topic;state.difficulty=$('#difficulty')?.value||state.difficulty;state.count=Number($('#count')?.value||10);state.mode=$('#mode')?.value||'oefen';state.questions=Array.from({length:state.count},()=>makeQuestion(state.topic,state.difficulty));state.index=0;state.page='practice';persist();render()}
function navigate(d){let q=state.questions[state.index];if(q&&q.type!=='choice'){let el=$('#answer');if(el)q.answer=el.value}state.index=Math.max(0,Math.min(state.questions.length-1,state.index+d));persist();render()}
async function aiCall(action,payload){let r=await fetch('/.netlify/functions/ai',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({action,...payload})});if(!r.ok)throw Error((await r.json().catch(()=>({}))).error||'AI momenteel niet beschikbaar');return r.json()}
async function checkAI(){
 const controller=new AbortController();const cutoff=setTimeout(()=>controller.abort(),3500);
 try {const r=await fetch('/.netlify/functions/ai',{method:'GET',signal:controller.signal});state.aiStatus=r.ok&&(await r.json()).available===true;}
 catch {state.aiStatus=false;}finally{clearTimeout(cutoff)}
 // Update only the connection badge: don't re-render the entire website or erase typed answers.
 const badge=document.querySelector('.topRight .pill');if(badge)badge.textContent=isAI()?'✦ Gemini AI verbonden':'◌ Offline oefenmodus';
 if(state.page==='tutor')render();
}
function handlers(ev){let el=ev.target.closest('[data-action]');if(!el)return;let [action,arg]=el.dataset.action.split(':');switch(action){case'register':registerStudent();break;case'refreshBoard':loadBoard(true);break;case'symbols':state.page='theory';render();setTimeout(()=>document.getElementById('symbolSearch')?.focus(),0);break;case'page':if(arg==='practice')state.questions=[];page(arg);if(arg==='leerlingen')loadBoard();break;case'menu':state.mobile=!state.mobile;render();break;case'theme':state.theme=state.theme==='dark'?'light':'dark';document.body.classList.toggle('light',state.theme==='light');persist();render();break;case'topic':state.topic=arg;state.questions=[];page('practice');break;case'theory':state.topic=arg;render();break;case'practiceTopic':state.questions=[];page('practice');break;case'start':start();break;case'resume':page(state.questions.length?'practice':'chapters');break;case'next':navigate(1);break;case'prev':navigate(-1);break;case'choice':{let q=state.questions[state.index];q.answer=q.options[Number(arg)];persist();render();break}case'check':check();break;case'hint':state.questions[state.index].hint=true;render();break;case'theoryCurrent':state.topic=state.questions[state.index].topic;page('theory');break;case'bookmark':{let id=state.questions[state.index].id;state.bookmarks=state.bookmarks.includes(id)?state.bookmarks.filter(x=>x!==id):[...state.bookmarks,id];persist();render();break}case'simpler':case'why':{let q=state.questions[state.index];alert(action==='simpler'?`De formule is ${q.formula}. ${q.steps.slice(-2).join(' ')}`:q.issue||q.mistake);break}case'similar':{let q=state.questions[state.index];state.questions.splice(state.index+1,0,makeQuestion(q.topic,q.difficulty));navigate(1);break}case'stop':if(confirm('Wil je de oefensessie verlaten? Je kunt later verdergaan via “Verder leren”.'))page('dashboard');break;case'finish':{let qs=state.questions;state.sessions.push({time:new Date().toISOString(),topic:qs[0]?.topic||state.topic,count:qs.length,correct:qs.filter(q=>q.checked&&q.correct).length});state.page='finish';persist();render();syncProgress();break}case'reviewStart':{let qs=state.mistakes.map(m=>({...m.question,id:'review'+Date.now()+Math.random(),answer:'',checked:false}));state.questions=qs;state.index=0;state.mode='oefen';state.page='practice';persist();render();break}case'saveConfig':document.querySelectorAll('[data-config]').forEach(x=>{state.config[x.dataset.config]={name:x.value.trim()||topic(x.dataset.config).name}});persist();alert('Hoofdstuktitels opgeslagen.');render();break;case'clear':if(confirm('Alle opgeslagen antwoorden, sessies en fouten definitief verwijderen?')){localStorage.removeItem(KEY);location.reload()}break;case'send':sendChat();break;case'startAI':startAI();break}}
async function startAI(){const id=$('#topicSelect')?.value||state.topic,level=$('#difficulty')?.value||state.difficulty,ct=Number($('#count')?.value||10),mode=$('#mode')?.value||'oefen';try{let btn=document.querySelector('[data-action="startAI"]');btn.disabled=true;btn.textContent='AI genereert vragen…';let data=await aiCall('generate',{topic:topic(id).name,difficulty:level,count:ct});if(!Array.isArray(data.questions)||!data.questions.length)throw Error('Geen vragen ontvangen');state.questions=data.questions.map((q,i)=>({id:'ai'+Date.now()+i,topic:id,difficulty:level,type:'numeric',text:q.text,value:Number(q.value),unit:q.unit,formula:q.formula,steps:q.steps,mistake:q.mistake,answer:'',checked:false,source:'ai'})).filter(q=>Number.isFinite(q.value));if(!state.questions.length)throw Error('Ongeldige vragen ontvangen');state.topic=id;state.mode=mode;state.index=0;state.page='practice';persist();render()}catch(e){alert('AI-vragen konden niet geladen worden: '+e.message);render()}}
async function sendChat(){let input=$('#chatInput');let msg=input?.value.trim();if(!msg||state.loading||!isAI())return;state.chat.push({role:'user',content:msg});state.loading=true;render();try{let r=await aiCall('chat',{messages:state.chat.slice(-12),topic:topic(state.topic).name,question:state.questions[state.index]?.text||null});state.chat.push({role:'assistant',content:String(r.reply||'Geen antwoord ontvangen.')})}catch(e){state.chat.push({role:'assistant',content:'De AI-verbinding werkte niet: '+e.message})}state.loading=false;render()}
document.addEventListener('click',handlers);document.addEventListener('input',e=>{if(e.target.id==='answer'){let q=state.questions[state.index];if(q){q.answer=e.target.value;persist()}}});document.addEventListener('keydown',e=>{if(!student&&e.key==='Enter'&&document.activeElement?.id==='studentName'){registerStudent();return}if(state.page!=='practice'||!state.questions.length||['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName))return;if(e.key==='ArrowLeft'){e.preventDefault();navigate(-1)}if(e.key==='ArrowRight'){e.preventDefault();navigate(1)}});render();if(student?.token)syncProgress();window.addEventListener('load',()=>setTimeout(checkAI,250),{once:true});
})();

document.addEventListener('click', e=>{let key=e.target.closest('[data-insert]');if(!key)return;let input=document.getElementById(key.dataset.target);if(!input||input.disabled)return;let from=input.selectionStart??input.value.length,to=input.selectionEnd??from;input.value=input.value.slice(0,from)+key.dataset.insert+input.value.slice(to);input.focus();input.setSelectionRange(from+key.dataset.insert.length,from+key.dataset.insert.length);input.dispatchEvent(new Event('input',{bubbles:true}));});
document.addEventListener('input',e=>{if(e.target.id!=='symbolSearch')return;let term=e.target.value.trim().toLowerCase();document.querySelectorAll('[data-symbol-search]').forEach(el=>el.hidden=!el.dataset.symbolSearch.includes(term));});
